app.controller('messageController',function($scope){
    $scope.message='message'
    console.log('message')
})