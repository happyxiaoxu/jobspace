/**
 * Created by xiaoxu on 3/18/2019.
 */
app.controller('homeController', ['$window', '$scope', '$timeout', '$firebaseArray', '$firebaseObject', 
    function ($window, $scope,$timeout, $firebaseArray, $firebaseObject) {
        $scope.message = 'home page'
        console.log('home page')
    }

]);

