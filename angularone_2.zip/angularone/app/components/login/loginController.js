/**
 * Created by xiaoxu on 3/18/2019.
 */
app.controller('loginController', function ($scope, authService, $firebaseObject) {
    // $scope.message = 'login'

    $scope.LoginUser = function () {
        // var ref =firebase.database().ref("users");
        // $scope.data = $firebaseObject(ref);
        var email = $scope.UserModel.email;
        var password = $scope.UserModel.password;
        var info = { 'email': email, 'password': password }
        authService.login(info)
            .then(user => {
                console.log(user)
                localStorage.setItem('uid', user.user.uid);
                localStorage.setItem('email',user.user.email);
                console.log('Logged In')
                
                window.location.href = '#/freelancer/dashboard';
                location.reload()
            })
            .catch(err => {
                alert(err.message)
            })
        
    }
}
);