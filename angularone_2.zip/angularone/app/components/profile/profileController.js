app.controller('profileController',function($scope){
    $scope.message='profile setting'
    console.log('profile setting')
})