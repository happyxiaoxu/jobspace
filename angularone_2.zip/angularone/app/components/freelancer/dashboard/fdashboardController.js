app.controller('fdashboardController',function($scope,authService){
    $scope.message='dashboard'
    console.log('dashboard')
})