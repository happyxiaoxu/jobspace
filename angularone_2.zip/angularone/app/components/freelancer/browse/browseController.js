app.controller('browseController',function($scope){
    $scope.message = 'browse jobs'
    console.log('browse jobs')
})