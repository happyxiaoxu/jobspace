app.controller('registerController', 
function ($scope, authService, $firebaseArray, $firebaseObject) {
    $scope.addUserModel = function () {

        if ($scope.UserModel.type == null) {
            alert('Please select type of user!')
            return
        }
        if ($scope.UserModel.password != $scope.UserModel.confirm_password) {
            alert('Password is not correct!,please retype again.')
            return
        }
        else {
            // const firestore = getFirestore();
            var username = $scope.UserModel.name;
            var email = $scope.UserModel.email;
            var password = $scope.UserModel.password;
            var type = $scope.UserModel.type;
            var user = { 'email': email, 'password': password }

            authService.register(user).then(resp => {
            
                var ref = firebase.database().ref("users")
                var users = $firebaseArray(ref);
                users.$add({
                    username: username,
                    user_id: resp.user.uid,
                    type: type
                })
                console.log('User registered successfully');
            window.location.href = '#/login'

            })
            .catch(err => {
                console.log(err.message)
                alert(err.message)
            })
        }
    }
})