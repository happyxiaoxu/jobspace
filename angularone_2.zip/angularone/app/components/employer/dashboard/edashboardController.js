app.controller('edashboardController',function($scope){
    $scope.message = 'employer dashboard'
    console.log('employer dashboard')
})