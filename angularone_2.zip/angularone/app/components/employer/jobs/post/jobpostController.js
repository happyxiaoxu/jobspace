app.controller('jobpostController',function($scope){
    $scope.message='job post'
    console.log('job post')
})