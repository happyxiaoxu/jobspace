app.controller('jobmanageController',function($scope){
    $scope.message='job manage'
    console.log('job manage')
})