app.service('authMiddleware', function (authService) {
    var service = {
        check:check
    }
    return service;

    function check() {
        console.log('///////////////////////////////')
        var flag = authService.isLoggedIn();
        if (!flag) {
            window.location.href = '#/login';
        }
        else {
            continue
        }
    }
})