/**
 * Created by xiaoxu on 3/18/2019.
 */
var app = angular.module('myApp', ['ngRoute', 'firebase']);
app.config(function ($routeProvider) {
    $routeProvider
        .when('/', {
            controller: 'homeController',
            templateUrl: 'app/components/home/home.html'
        })
        .when('/login', {
            controller: 'loginController',
            templateUrl: 'app/components/login/login.html'
        })
        .when('/register', {
            controller: 'registerController',
            templateUrl: 'app/components/register/register.html'
        })
        .when('/freelancer/dashboard', {
            controller: 'fdashboardController',
            templateUrl: 'app/components/freelancer/dashboard/fdashboard.html',
        })
        .when('/freelancer/browse', {
            controller: 'browseController',
            templateUrl: 'app/components/freelancer/browse/browse.html'
        })
        .when('/employer/dashboard', {
            controller: 'edashboardController',
            templateUrl: 'app/components/employer/dashboard/edashboard.html'
        })
        .when('/message', {
            controller: 'messageController',
            templateUrl: 'app/components/message/message.html'
        })
        .when('/profile', {
            controller: 'profileController',
            templateUrl: 'app/components/profile/profile.html'
        })
        .when('/jobs/post', {
            controller: 'jobpostController',//
            templateUrl: 'app/components/employer/jobs/post/jobpost.html'
        })
        .when('/jobs/manage', {
            controller: 'jobmanageController',//
            templateUrl: 'app/components/employer/jobs/manage/jobmanage.html'
        })
        .otherwise({
            redirectTo: '/'
        });
})
.run(['$rootScope', '$location', '$http',
    function ($rootScope, $location, $http) {
        $rootScope.$on('$locationChangeStart', function (event, next, current) {
            // redirect to login page if not logged in
            if ($location.path() !== '/login' && localStorage.getItem('uid') == null) {
                $location.path('/login');
            }
        });
    }]);

app.constant("fburl",
    "https://jobspace-77038.firebaseio.com/" //Use the URL of your project here
);
// app.run(["$rootScope", "$state", function($rootScope, $state) {

//     $rootScope.$on('$stateChangeStart', function(event, toState, toParams, fromState, fromParams, options) { 
//         if (true) {
//             event.preventDefault(); // prevent routing to the state
//             window.location.href='#/login'
//         }
//         // else do nothing, it will just transition to the given state
//     })
// }]);
////////////////////////////////