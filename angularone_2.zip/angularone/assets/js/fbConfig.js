// Initialize Firebase
var config = {
    apiKey: "AIzaSyDpjYesGQ8IOn37E-hJ9PxnZrvclmA2phU",
    authDomain: "jobspace-77038.firebaseapp.com",
    databaseURL: "https://jobspace-77038.firebaseio.com",
    projectId: "jobspace-77038",
    storageBucket: "jobspace-77038.appspot.com",
    messagingSenderId: "562340663113"
  };
  firebase.initializeApp(config);
  // firebase.firestore().settings({ timestampsInSnapshots: true });