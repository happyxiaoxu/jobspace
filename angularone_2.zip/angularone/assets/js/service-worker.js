
self.addEventListener('install', function(event) {});
